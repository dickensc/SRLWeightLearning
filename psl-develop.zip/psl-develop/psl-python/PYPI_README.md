## pslpython

A Python interface to the PSL SRL framework.

PSL information can be found at: [psl.linqs.org](https://psl.linqs.org/).
Example usage can be in the PSL Examples repository:
 - [Stable](https://github.com/linqs/psl-examples)
 - [Development](https://github.com/linqs/psl-examples/tree/develop)
